import 'dart:developer';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:marathon/data/storage/app/app_holder.dart';

import '../../firebase_options.dart';

class NotificationService {
  static FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  static AndroidNotificationChannel channel = const AndroidNotificationChannel(
    'high_channel', // id
    'High Importance Notifications', // title
    // 'This channel is used for important notifications.', // description
    importance: Importance.max,
  );

  getFCMToken() async {
    log('hello...');
    FirebaseMessaging messaging = FirebaseMessaging.instance;
    try {
      String? token = await messaging.getToken();
      log('FcmToken===>>> $token');
      Get.find<AppHolder>().fCMToken = token ?? "";
      log('Get.find<AppHolder>().fCMToken==========>>>>>${Get.find<AppHolder>().fCMToken}');
    } catch (e) {
      log('eeee>> $e');
    }
  }

  static void showMsgHandler() {
    FirebaseMessaging.onMessage.listen((RemoteMessage? message) {
      print("message=====>$message");
      RemoteNotification? notification = message!.notification;
      AndroidNotification? android = message.notification?.android;
      log('NOtification Call :${notification?.apple}${notification!.body}${notification.title}${notification.bodyLocKey}${notification.bodyLocKey}');
      if (message != null) {
        showMsg(notification);
      }
    });
  }

  /// handle notification when app in fore ground..///close app
  static void getInitialMsg() {
    FirebaseMessaging.instance
        .getInitialMessage()
        .then((RemoteMessage? message) {
      log('------RemoteMessage message------$message');
      if (message != null) {
      }
    });
  }

  ///show notification msg
  static void showMsg(RemoteNotification notification) {
    flutterLocalNotificationsPlugin.show(
        notification.hashCode,
        '${notification.title}',
        '${notification.body}',
        const NotificationDetails(
            android: AndroidNotificationDetails(
              'high_channel',
              'High Importance Notifications',
              //'This channel is used for important notifications.',
              // description
              importance: Importance.max,
              icon: '@mipmap/ic_launcher',
            ),
            iOS: DarwinNotificationDetails()));
    log('notification.title==========>>>>>${notification.title}');
    log('notification.body==========>>>>>${notification.body}');
  }

  ///background notification handler..
  static Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    log('Handling a background message ${message.data}');
    RemoteNotification? notification = message.notification;
    log('notification==========>>>>>$notification');
  }

  ///call when click on notification back
  static void onMsgOpen() {
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      log('A new onMessageOpenedApp event was published!');
      log('listen->${message.data}');
    });
  }

}
