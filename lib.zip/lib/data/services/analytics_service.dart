import 'dart:io';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:get/get.dart';
import 'package:marathon/data/storage/app/app_holder.dart';
import 'package:package_info_plus/package_info_plus.dart';

class AnalyticsService {
  AnalyticsService._();

  static final _instance = AnalyticsService._();

  static AnalyticsService get instance => _instance;

  final _analytics = FirebaseAnalytics.instance;

  void onAppOpen() {
    try {
      _analytics.logAppOpen();
      // _analytics.logLevelStart(levelName: 'start_test');
    } catch (e) {
      print(e);
    }
  }

  void onLogin({
    required String loginType,
    required int userId,
  }) async {
    try {
      // _analytics.logLogin(loginMethod: loginType);
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name: 'UserId', value: '$userId');
      _analytics.logEvent(
        name: 'user_logged_in',
        parameters: {
          'UserId': userId,
        },
      ).onError((error, stack) {
        print('TAG:: onLogin: onError >>>>>>>> ');
      }).catchError((error) {
        print('TAG:: onLogin: catchError >>>>>>>> ');
      });
    } catch (e) {
      print(e);
    }
  }

  void onProjectName({required String projectName}) async {
    try {
      final userId = Get.find<AppHolder>().custId;
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name: 'UserId', value: '$userId');
      _analytics.setUserProperty(name: 'ProjectName', value: projectName);
      _analytics.logEvent(
        name: 'user_logged_in',
        parameters: {
          'UserId': userId,
          'ProjectName': projectName,
        },
      ).onError((error, stack) {
        print('TAG:: onLogin: onError >>>>>>>> ');
      }).catchError((error) {
        print('TAG:: onLogin: catchError >>>>>>>> ');
      });
    } catch (e) {
      print(e);
    }
  }

  void onRegister({
    required String loginType,
    required int userId,
    required int custId,
    required String userName,
    required String email,
    required String mobile,
  }) async {
    try {
      final packageInfo = await PackageInfo.fromPlatform();
      _analytics.logSignUp(signUpMethod: loginType);
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name: 'userName', value: userName);
      _analytics.setUserProperty(name: 'email', value: email);
      _analytics.logEvent(
        name: 'register',
        parameters: {
          'userId': userId,
          'custId': custId,
          'userName': userName,
          'email': email,
          'mobile': mobile,
          'app_version': packageInfo.version,
          'platform': Platform.isAndroid ? 'Android' : 'iOS',
          'timestamp': DateTime.now().toIso8601String(),
        },
      );
    } catch (e) {
      print(e);
    }
  }

  void onHomeScreenView() async {
    try {
      _analytics.logScreenView(
        screenName: 'HomeScreen',
        screenClass: 'MainPage',
      );
      final userId = Get.find<AppHolder>().custId;
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name: 'UserId', value: '$userId');
      _analytics.logEvent(
        name: 'screen_view',
        parameters: {
          'screen_name': 'HomeScreen',
          'UserId': userId,
        },
      );
    } catch (e) {
      print(e);
    }
  }

  void onContactFormSubmission() async {
    try {
      final userId = Get.find<AppHolder>().custId;
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name:'UserId', value: '$userId');
      _analytics.logEvent(
        name: 'support_screen',
        parameters: {
          'UserId': userId,
        },
      );
    } catch (e) {
      print(e);
    }
  }

  void onDocumentUpload() async {
    try {
      final userId = Get.find<AppHolder>().custId;
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name: 'UserId', value: '$userId');
      _analytics.logEvent(
        name: 'document_screen',
        parameters: {
          'UserId': userId,
        },
      );
    } catch (e) {
      print(e);
    }
  }

  void onReferred() async {
    try {
      final userId = Get.find<AppHolder>().custId;
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name: 'UserId', value: '$userId');
      _analytics.logEvent(
        name: 'referred_screen',
        parameters: {
          'UserId': userId,
        },
      );
    } catch (e) {
      print(e);
    }
  }

  void onPayment() async {
    try {
      final userId = Get.find<AppHolder>().custId;
      _analytics.setUserId(id: '$userId');
      _analytics.setUserProperty(name: 'UserId', value: '$userId');
      _analytics.logEvent(
        name: 'payment_screen',
        parameters: {
          'UserId': userId,
        },
      );
    } catch (e) {
      print(e);
    }
  }
}
