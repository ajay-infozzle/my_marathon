enum SocialLink { telegram, instagram, facebook, youTube }
