enum SocketMsgType {
  messageProfile,
  messageGroup,
  callBattle,
  createBattle,
  startBattle,
  notification,
  newMessage,
  unknown
}
