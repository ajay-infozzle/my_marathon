enum AudioCheckingStatus { start, recording, correct, incorrect, finished }
