enum PaymentType { uzCard, click, payme }
