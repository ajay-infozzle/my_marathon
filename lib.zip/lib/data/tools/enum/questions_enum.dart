enum PracticeType { repeat, practise, exercise, battle }
