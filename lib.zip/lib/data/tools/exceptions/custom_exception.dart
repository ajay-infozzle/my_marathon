class NotValidException implements Exception {
  String message;

  NotValidException(this.message);
}
