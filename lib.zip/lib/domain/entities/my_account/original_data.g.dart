// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'original_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OriginalData _$OriginalDataFromJson(Map<String, dynamic> json) => OriginalData(
      status: json['status'] as String?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$OriginalDataToJson(OriginalData instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
    };
