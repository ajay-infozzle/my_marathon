// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'faq_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FaqData _$FaqDataFromJson(Map<String, dynamic> json) => FaqData(
      category: json['category'] as String?,
      question: json['question'] as String?,
      answer: json['answer'] as String?,
    );

Map<String, dynamic> _$FaqDataToJson(FaqData instance) => <String, dynamic>{
      'category': instance.category,
      'question': instance.question,
      'answer': instance.answer,
    };
