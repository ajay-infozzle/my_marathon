// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'terms_and_condition_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TermsAndConditionResponse _$TermsAndConditionResponseFromJson(
        Map<String, dynamic> json) =>
    TermsAndConditionResponse(
      content: json['content'] as String?,
    );

Map<String, dynamic> _$TermsAndConditionResponseToJson(
        TermsAndConditionResponse instance) =>
    <String, dynamic>{
      'content': instance.content,
    };
